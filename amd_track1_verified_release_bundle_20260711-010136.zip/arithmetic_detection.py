"""Shared deterministic arithmetic prompt detection."""

from __future__ import annotations

import re
from typing import Optional


_OPERATOR_PATTERN = re.compile(r"(\*\*|[+\-*/%^])")
_DIGIT_PATTERN = re.compile(r"\d")
_PERCENT_OF_PATTERN = re.compile(
    r"(\d+(?:\.\d+)?)\s*%\s+of\s+(\d+(?:\.\d+)?)",
    flags=re.IGNORECASE,
)


def extract_arithmetic_expression(prompt: str) -> Optional[str]:
    """Extract a calculator-safe arithmetic expression from a prompt."""
    if not prompt:
        return None

    percent_of = _PERCENT_OF_PATTERN.search(prompt)
    if percent_of:
        return f"{percent_of.group(1)}% * {percent_of.group(2)}"

    allowed_chars = set("0123456789.+-*/%^() \t")
    candidates: list[str] = []
    start: Optional[int] = None

    for index, char in enumerate(prompt):
        if char in allowed_chars:
            if start is None:
                start = index
        elif start is not None:
            candidates.append(prompt[start:index].strip())
            start = None

    if start is not None:
        candidates.append(prompt[start:].strip())

    candidates.sort(key=len, reverse=True)

    for candidate in candidates:
        expression = candidate.strip(" \t.:,;?!")
        if _DIGIT_PATTERN.search(expression) and _OPERATOR_PATTERN.search(expression):
            return expression

    return None


def has_arithmetic_expression(prompt: str) -> bool:
    """Return True when the prompt contains a deterministic arithmetic expression."""
    return extract_arithmetic_expression(prompt) is not None
