"""
AMD Track 1 Entry Point

Main entry point for the AMD Track 1 general-purpose AI agent.
Reads /input/tasks.json, processes tasks, writes /output/results.json.

FIX: removed the local_mode_enabled bypass that made FIREWORKS_API_KEY /
FIREWORKS_BASE_URL / ALLOWED_MODELS optional. Since router.py and
difficulty_gate.py no longer have any local-inference code path, that
bypass was dead logic that could only ever fail loudly (or worse, silently
misconfigure) rather than actually enabling anything. Fireworks env vars
are now unconditionally required, matching what the rest of the codebase
actually does.
"""

import argparse
import json
import os
import sys
from typing import List, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from .executor import TaskExecutor, get_executor
from .model_registry import get_model_registry
from .classifier import get_classifier


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='AMD Track 1 General-Purpose AI Agent'
    )

    parser.add_argument(
        '--input',
        default='/input/tasks.json',
        help='Path to input tasks.json'
    )

    parser.add_argument(
        '--output',
        default='/output/results.json',
        help='Path to output results.json'
    )

    parser.add_argument(
        '--skills-dir',
        default=None,
        help='Directory containing skill definitions (default: amd_track1/skills)'
    )

    parser.add_argument(
        '--max-concurrency',
        type=int,
        default=4,
        help='Maximum concurrent requests (default: 4)'
    )

    parser.add_argument(
        '--timeout',
        type=float,
        default=600.0,  # 10 minutes
        help='Maximum total execution time in seconds (default: 600)'
    )

    args = parser.parse_args()

    input_path = args.input
    output_path = args.output

    if args.skills_dir:
        skills_dir = args.skills_dir
    else:
        skills_dir = os.path.join(os.path.dirname(__file__), 'skills')

    try:
        executor = get_executor(
            skills_dir=skills_dir,
            max_concurrency=args.max_concurrency
        )
    except Exception as e:
        print(f"Error initializing executor: {e}", file=sys.stderr)
        sys.exit(1)

    try:
        # Fireworks config is unconditionally required. There is no local
        # fallback mode — the rest of the codebase has no code path that
        # can use one, so accepting these as optional here would only let
        # the container start into a broken state instead of failing fast.
        api_key = os.environ.get('FIREWORKS_API_KEY')
        base_url = os.environ.get('FIREWORKS_BASE_URL')
        allowed_models = os.environ.get('ALLOWED_MODELS')

        missing = []
        if not api_key:
            missing.append('FIREWORKS_API_KEY')
        if not base_url:
            missing.append('FIREWORKS_BASE_URL')
        if not allowed_models:
            missing.append('ALLOWED_MODELS')

        if missing:
            print(f"Error: required environment variable(s) not set: {', '.join(missing)}", file=sys.stderr)
            sys.exit(1)

        success = executor.initialize(allowed_models)
        if not success:
            print("Error: Failed to initialize model registry", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        print(f"Error during initialization: {e}", file=sys.stderr)
        sys.exit(1)

    try:
        start_time = __import__('time').time()

        success, errors = executor.process_input(
            input_path, output_path, total_timeout=args.timeout
        )

        elapsed = __import__('time').time() - start_time

        if success:
            try:
                with open(output_path, 'r') as f:
                    output_data = json.load(f)
                    task_count = len(output_data)
            except Exception:
                task_count = 0
            print(f"Successfully processed {task_count} tasks in {elapsed:.2f}s", file=sys.stderr)
            sys.exit(0)
        else:
            print(f"Completed with errors in {elapsed:.2f}s:", file=sys.stderr)
            for error in errors:
                print(f"  - {error}", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        print(f"Error during execution: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
