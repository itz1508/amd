# AMD Agent Instructions

## Repository authority

- `D:\Dev\amd` is the only active authority for this project.
- `D:\Dev\Edge` is obsolete. Do not read, copy, merge, or restore code from it unless the user explicitly reauthorizes it.
- Resolve paths relative to `D:\Dev\amd` unless an external runtime path is explicitly required.

## Execution and evidence

- Execute implementation requests directly; do not return another plan.
- Ask only when destructive action, secret entry, or genuine ambiguity blocks safe progress.
- Inspect the actual code, logs, environment, and active call path after failures.
- Never claim completion from static inspection or import success alone.
- Completion claims require commands, exit codes, tests, and runtime artifacts.
- Report verified, inferred, unknown, and blocked states separately.

## Configuration and secrets

Production code and Dockerfiles must not hardcode API keys, Fireworks URLs, model IDs, allowed-model lists, local model paths, developer paths, image digests, registry credentials, or benchmark answers.

Required inference variables are read only from the environment:

- `FIREWORKS_API_KEY`
- `FIREWORKS_BASE_URL`
- `ALLOWED_MODELS`

Never print, echo, commit, log, screenshot, or store secrets. Revoke any accidentally exposed credential immediately.

## Track 1 runtime authority

Canonical flow:

```text
input validation -> classification -> deterministic tool when provably eligible
-> Fireworks for remaining tasks -> category validation -> evidence -> atomic output
```

Production routes are `deterministic`, `fireworks`, and `blocked`. No local-model route is active in the submission runtime unless explicitly re-enabled by the user.

Supported categories are exactly:

`factual_knowledge`, `mathematical_reasoning`, `sentiment_classification`, `text_summarisation`, `named_entity_recognition`, `code_debugging`, `logical_reasoning`, `code_generation`.

Unknown input remains `unknown` or is explicitly blocked; it must not silently become factual knowledge.

## Fireworks client rules

- Treat `FIREWORKS_BASE_URL` as runtime input and normalize it in one authoritative location.
- Direct HTTP mode appends exactly one `/chat/completions`; never create duplicated paths.
- Select models only from parsed `ALLOWED_MODELS`; role overrides must also be allowlist-validated.
- Retry transport, timeout, connection, 429, and 5xx failures only. Do not retry permanent 4xx/auth/model errors.
- Preserve time for validation and output writing within the 600-second runtime budget.

## Skills, tools, and evidence

- Skills describe capability and policy; tools implement operations.
- The classifier selects a registered skill; the invoker resolves stable tool IDs; the executor owns orchestration.
- Models may not invent arbitrary tool names.
- Keep production evidence separate from benchmark expectations. Production evidence may include selected category, skill, tools, route, duration, validation, and fallback reason, but not hidden expected answers or benchmark truth labels.

## Track boundaries

- Track 1 changes belong under `amd_track1`.
- Track 2 changes belong under `amd_track2`.
- Do not modify both tracks without evidence that both are required.
- Do not include unrelated track files in a commit or image.

## Windows and Docker

- Primary shell is Windows PowerShell 5.1. Use PowerShell syntax, not Bash continuation or commands.
- Use Windows host paths for Docker mounts and Linux paths only inside containers.
- Docker target is `linux/amd64`; verify architecture instead of assuming it.
- The final image runs as root because bind-mounted `/output` may be root-owned.

## Validation gates

Before success is claimed:

1. Run focused tests for changed components.
2. Run the complete applicable Track test suite.
3. Run compile/import checks.
4. Run the actual entrypoint.
5. Run evaluator-style mounted `/input` and `/output` container tests for runtime changes.

Container proof must show: correct architecture and entrypoint, no secrets or forced local model, input read, output written, exact task cardinality, preserved IDs, string answers, and exit code 0.

Mocked requests are not live Fireworks proof. Benchmarks must time the real callable with `time.perf_counter()` and keep fixtures outside production runtime.

## Release and Git discipline

- Inspect status before editing; preserve unrelated dirty files.
- Stage only intended files and exclude caches, secrets, outputs, and unrelated artifacts.
- Tests, runtime preflight, diff review, architecture verification, and evaluator-style smoke must pass before rebuilding or pushing.
- Before submission: push immutable and latest tags, logout, pull anonymously, compare digests, and rerun the pulled image.
- Report changed files, commands, exit codes, commit/push state, and remaining blockers.

## Stop conditions

Stop only for unavailable required credentials, rejected valid remote configuration, unsafe destructive ambiguity, blocked external dependency/permission, or unavailable required environment. Diagnose and retry ordinary command failures within scope.

## Source-of-truth relationship

This file owns agent operating rules. `Source_Of_Truth.md` records current project architecture, interfaces, and verification status; it must not duplicate or override these rules.
