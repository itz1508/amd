"""Integration tests for the v3 Fireworks-only routing policy."""

import unittest

from amd_track1.category_validator import CategoryValidator
from amd_track1.difficulty_gate import (
    RoutePolicy,
    choose_route,
    is_deterministic_solvable,
)


class TestRoutePolicyIntegration(unittest.TestCase):
    """Test that RoutePolicy follows the v3 Fireworks-only contract."""

    def test_route_policy_exists_and_works(self):
        policy = RoutePolicy()
        decision = policy.choose_route(
            category="sentiment_classification",
            prompt="I love this product!",
        )
        self.assertEqual(decision.route, "fireworks")
        self.assertFalse(decision.requires_validation)

    def test_deterministic_arithmetic_bypasses_fireworks(self):
        decision = choose_route(
            category="mathematical_reasoning",
            prompt="What is 2 + 3?",
            deterministic_supported=True,
        )
        self.assertEqual(decision.route, "deterministic")
        self.assertFalse(decision.requires_validation)

    def test_deterministic_percentage_bypasses_fireworks(self):
        decision = choose_route(
            category="mathematical_reasoning",
            prompt="What is 15% of 200?",
            deterministic_supported=True,
        )
        self.assertEqual(decision.route, "deterministic")

    def test_multi_operator_arithmetic_is_deterministic(self):
        decision = choose_route(
            category="mathematical_reasoning",
            prompt="What is 2 + 3 * 4 - 1?",
            deterministic_supported=True,
        )
        self.assertEqual(decision.route, "deterministic")

    def test_non_deterministic_categories_route_to_fireworks(self):
        cases = [
            ("sentiment_classification", "I love this!"),
            ("factual_knowledge", "What is the capital of France?"),
            ("text_summarisation", "Summarize this: " + "Some text. " * 50),
            ("code_generation", "Write a Python function to sort a list."),
            ("code_debugging", "Fix this code: def foo(): return"),
            ("logical_reasoning", "If all A are B and all B are C, are all A C?"),
            ("unknown", "Do something weird."),
        ]

        for category, prompt in cases:
            with self.subTest(category=category):
                decision = choose_route(category=category, prompt=prompt)
                self.assertEqual(decision.route, "fireworks")

    def test_deterministic_can_be_disabled(self):
        decision = choose_route(
            category="mathematical_reasoning",
            prompt="What is 2 + 3?",
            deterministic_supported=False,
        )
        self.assertEqual(decision.route, "fireworks")


class TestCategoryValidatorSentiment(unittest.TestCase):
    """Test sentiment validation is tight."""

    def setUp(self):
        self.validator = CategoryValidator()

    def test_valid_positive(self):
        valid, errors = self.validator.validate(
            "sentiment_classification", "I love this", "positive"
        )
        self.assertTrue(valid)

    def test_valid_negative(self):
        valid, errors = self.validator.validate(
            "sentiment_classification", "I hate this", "negative"
        )
        self.assertTrue(valid)

    def test_valid_neutral(self):
        valid, errors = self.validator.validate(
            "sentiment_classification", "It is okay", "neutral"
        )
        self.assertTrue(valid)

    def test_invalid_label_rejected(self):
        valid, errors = self.validator.validate(
            "sentiment_classification", "I love this", "happy"
        )
        self.assertFalse(valid)

    def test_empty_answer_rejected(self):
        valid, errors = self.validator.validate(
            "sentiment_classification", "I love this", ""
        )
        self.assertFalse(valid)

    def test_justification_without_request_rejected(self):
        valid, errors = self.validator.validate(
            "sentiment_classification",
            "I love this product",
            "positive because it is great",
        )
        self.assertFalse(valid)

    def test_capitalized_label_normalized(self):
        valid, errors = self.validator.validate(
            "sentiment_classification", "I love this", "Positive"
        )
        self.assertTrue(valid)


class TestDeterministicSolvable(unittest.TestCase):
    """Test deterministic solver detection."""

    def test_simple_addition(self):
        ok, reason = is_deterministic_solvable(
            "mathematical_reasoning", "What is 2 + 3?"
        )
        self.assertTrue(ok)
        self.assertEqual(reason, "Deterministic arithmetic")

    def test_simple_multiplication(self):
        ok, reason = is_deterministic_solvable(
            "mathematical_reasoning", "Calculate 7 * 8"
        )
        self.assertTrue(ok)

    def test_percentage(self):
        ok, reason = is_deterministic_solvable(
            "mathematical_reasoning", "What is 15% of 200?"
        )
        self.assertTrue(ok)

    def test_complex_math_is_deterministic(self):
        ok, reason = is_deterministic_solvable(
            "mathematical_reasoning",
            "What is 2 + 3 * 4 - 1?",
        )
        self.assertTrue(ok)

    def test_sentiment_not_deterministic(self):
        ok, reason = is_deterministic_solvable(
            "sentiment_classification", "I love this!"
        )
        self.assertFalse(ok)


class TestRoutingEvidence(unittest.TestCase):
    """Test that routing decisions record evidence."""

    def test_decision_has_route_and_reason(self):
        decision = choose_route(
            category="sentiment_classification",
            prompt="I love this!",
        )
        self.assertEqual(decision.route, "fireworks")
        self.assertIsInstance(decision.reason, str)

    def test_decision_to_dict(self):
        decision = choose_route(
            category="sentiment_classification",
            prompt="I love this!",
        )
        d = decision.to_dict()
        self.assertEqual(d["route"], "fireworks")
        self.assertIn("reason", d)
        self.assertIn("requires_validation", d)
        self.assertNotIn("local_eligible", d)


if __name__ == "__main__":
    unittest.main()
